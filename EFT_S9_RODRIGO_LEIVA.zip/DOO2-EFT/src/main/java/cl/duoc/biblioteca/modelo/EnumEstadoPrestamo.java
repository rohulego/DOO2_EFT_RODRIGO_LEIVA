package cl.duoc.biblioteca.modelo;

public enum EnumEstadoPrestamo {
    DEVUELTO,
    PENDIENTE,
    ATRASADO,
    DEVUELTO_CON_ATRASO
}