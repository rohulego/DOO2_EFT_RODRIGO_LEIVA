package cl.duoc.biblioteca.vistas;

import cl.duoc.biblioteca.modelo.Estudiante;
import cl.duoc.biblioteca.service.BibliotecaService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class GestionEstudiantesPanel extends JPanel {

    private final BibliotecaService servicio;
    private JTable tablaEstudiantes;
    private DefaultTableModel modelTabla;
    private JTextField txtNombre, txtRut, txtCurso, txtCorreo;
    private JButton btnGuardar, btnLimpiar, btnEliminar, btnListar;
    private int idSeleccionado = 0;

    public GestionEstudiantesPanel(BibliotecaService servicio) {
        this.servicio = servicio;
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        initUI();
        cargarTabla(); // Carga automática de estudiantes desde MySQL
    }

    private void initUI() {
        // Panel de Formulario
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 8, 8));
        formPanel.setBorder(BorderFactory.createTitledBorder("Datos del Estudiante"));

        txtNombre = new JTextField();
        txtRut = new JTextField();
        txtCurso = new JTextField();
        txtCorreo = new JTextField();

        formPanel.add(new JLabel("Nombre Completo:"));
        formPanel.add(txtNombre);
        formPanel.add(new JLabel("RUT:"));
        formPanel.add(txtRut);
        formPanel.add(new JLabel("Curso:"));
        formPanel.add(txtCurso);
        formPanel.add(new JLabel("Correo Electrónico:"));
        formPanel.add(txtCorreo);

        // Botones de Acción
        btnGuardar = new JButton("Guardar / Actualizar");
        btnLimpiar = new JButton("Limpiar / Nuevo");
        btnEliminar = new JButton("Eliminar Seleccionado");
        btnListar = new JButton("Listar / Cargar Todo");

        JPanel formButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        formButtons.add(btnListar);
        formButtons.add(btnGuardar);
        formButtons.add(btnLimpiar);
        formButtons.add(btnEliminar);

        JPanel topContainer = new JPanel(new BorderLayout());
        topContainer.add(formPanel, BorderLayout.CENTER);
        topContainer.add(formButtons, BorderLayout.SOUTH);

        // Tabla de Estudiantes
        modelTabla = new DefaultTableModel(new String[]{"ID", "Nombre", "RUT", "Curso", "Correo"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tablaEstudiantes = new JTable(modelTabla);
        JScrollPane scrollTabla = new JScrollPane(tablaEstudiantes);

        add(topContainer, BorderLayout.NORTH);
        add(scrollTabla, BorderLayout.CENTER);

        // Eventos de los Botones
        btnListar.addActionListener(e -> cargarTabla());
        btnGuardar.addActionListener(e -> guardarEstudiante());
        btnLimpiar.addActionListener(e -> limpiarFormulario());
        btnEliminar.addActionListener(e -> eliminarEstudiante());

        // Evento al Seleccionar una Fila
        tablaEstudiantes.getSelectionModel().addListSelectionListener(e -> {
            int row = tablaEstudiantes.getSelectedRow();
            if (row >= 0) {
                idSeleccionado = (int) modelTabla.getValueAt(row, 0);
                txtNombre.setText((String) modelTabla.getValueAt(row, 1));
                txtRut.setText((String) modelTabla.getValueAt(row, 2));
                txtCurso.setText((String) modelTabla.getValueAt(row, 3));
                txtCorreo.setText((String) modelTabla.getValueAt(row, 4));
            }
        });
    }

    public void cargarTabla() {
        modelTabla.setRowCount(0);
        List<Estudiante> lista = servicio.listarEstudiantes();
        if (lista != null) {
            for (Estudiante e : lista) {
                modelTabla.addRow(new Object[]{e.getId(), e.getNombre(), e.getRut(), e.getCurso(), e.getCorreo()});
            }
        }
    }

    private void guardarEstudiante() {
        try {
            Estudiante e = new Estudiante(idSeleccionado, txtNombre.getText().trim(), txtRut.getText().trim(), txtCurso.getText().trim(), txtCorreo.getText().trim());
            if (servicio.guardarEstudiante(e)) {
                JOptionPane.showMessageDialog(this, "Estudiante procesado con éxito.");
                limpiarFormulario();
                cargarTabla();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarEstudiante() {
        if (idSeleccionado == 0) {
            JOptionPane.showMessageDialog(this, "Seleccione un estudiante de la tabla.");
            return;
        }


        // Verificamos si el estudiante tiene préstamos activos antes de preguntar o intentar borrar
        if (servicio.estudianteTienePendientes(idSeleccionado)) {
            JOptionPane.showMessageDialog(this,
                    "No se puede eliminar el estudiante porque tiene libros pendientes de devolución.",
                    "Acción Denegada",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "¿Eliminar este estudiante?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (servicio.eliminarEstudiante(idSeleccionado)) {
                JOptionPane.showMessageDialog(this, "Estudiante eliminado.");
                limpiarFormulario();
                cargarTabla();
            } else {
                JOptionPane.showMessageDialog(this, "Error al eliminar el estudiante.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void limpiarFormulario() {
        idSeleccionado = 0;
        txtNombre.setText("");
        txtRut.setText("");
        txtCurso.setText("");
        txtCorreo.setText("");
        tablaEstudiantes.clearSelection();
    }
}