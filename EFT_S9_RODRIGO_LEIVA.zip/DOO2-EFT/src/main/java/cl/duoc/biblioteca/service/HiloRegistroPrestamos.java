package cl.duoc.biblioteca.service;

import cl.duoc.biblioteca.service.BibliotecaService;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HiloRegistroPrestamos {

    private static final ExecutorService executor = Executors.newFixedThreadPool(4);

    public static void ejecutarEnSegundoPlano(
            BibliotecaService servicio,
            int idEstudiante,
            int idLibro,
            int diasPrestamo,
            Runnable callbackExito
    ) {
        executor.submit(() -> {
            try {

                boolean registrado = servicio.solicitarPrestamo(idEstudiante, idLibro, diasPrestamo);


                SwingUtilities.invokeLater(() -> {
                    if (registrado) {
                        JOptionPane.showMessageDialog(
                                null,
                                "¡Préstamo registrado exitosamente!",
                                "Éxito",
                                JOptionPane.INFORMATION_MESSAGE
                        );
                        if (callbackExito != null) {
                            callbackExito.run();
                        }
                    } else {
                        JOptionPane.showMessageDialog(
                                null,
                                "No se pudo procesar el préstamo en la base de datos.",
                                "Error",
                                JOptionPane.ERROR_MESSAGE
                        );
                    }
                });

            } catch (IllegalArgumentException | IllegalStateException ex) {

                SwingUtilities.invokeLater(() ->
                        JOptionPane.showMessageDialog(null, ex.getMessage(), "Atención", JOptionPane.WARNING_MESSAGE)
                );
            } catch (Exception ex) {
                // Excepciones inesperadas
                SwingUtilities.invokeLater(() ->
                        JOptionPane.showMessageDialog(null, "Error inesperado: " + ex.getMessage(), "Error de Sistema", JOptionPane.ERROR_MESSAGE)
                );
            }
        });
    }
}