package cl.duoc.biblioteca.vistas;

import cl.duoc.biblioteca.modelo.SesionUsuario;
import cl.duoc.biblioteca.modelo.Usuario;
import cl.duoc.biblioteca.service.BibliotecaService;

import javax.swing.*;
import java.awt.*;

public class MainView extends JFrame {

    private final BibliotecaService servicio;
    private JTabbedPane tabbedPane;

    public MainView(BibliotecaService servicio) {
        this.servicio = servicio;
        initUI();
    }

    private void initUI() {
        Usuario usuario = SesionUsuario.getUsuarioLogueado();
        if (usuario == null) {
            JOptionPane.showMessageDialog(this, "No hay una sesión activa.", "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
            return;
        }

        setTitle("Sistema de Biblioteca Escolar - Usuario: " + usuario.getNombre() + " (" + usuario.getRol() + ")");
        setSize(950, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        tabbedPane = new JTabbedPane();

        if ("bibliotecario".equalsIgnoreCase(usuario.getRol())) {
            GestionEstudiantesPanel panelEstudiantes = new GestionEstudiantesPanel(servicio);
            GestionLibrosPanel panelLibros = new GestionLibrosPanel(servicio);
            GestionPrestamosPanel panelPrestamos = new GestionPrestamosPanel(servicio, true);
            ReportesPanel panelReportes = new ReportesPanel(servicio);

            tabbedPane.addTab("Gestión de Estudiantes", panelEstudiantes);
            tabbedPane.addTab("Gestión de Libros", panelLibros);
            tabbedPane.addTab("Gestión de Préstamos", panelPrestamos);
            tabbedPane.addTab("Informes y Reportes", panelReportes);

            // Escuchador para refrescar los datos automáticamente al cambiar de pestaña
            tabbedPane.addChangeListener(e -> {
                Component panelSeleccionado = tabbedPane.getSelectedComponent();
                if (panelSeleccionado == panelLibros) {
                    panelLibros.cargarTabla(); // Refresca el stock de libros desde MySQL
                } else if (panelSeleccionado == panelPrestamos) {
                    panelPrestamos.cargarDatos(); // Refresca los préstamos y libros
                } else if (panelSeleccionado == panelEstudiantes) {
                    panelEstudiantes.cargarTabla(); // Refresca la lista de estudiantes
                }else if (panelSeleccionado == panelReportes) {
                    panelReportes.cargarEstudiantesCombo(); // Refresca lista en combo
                    panelReportes.cargarLibrosMasPrestados(); // Refresca ranking
                }
            });
        } else if ("estudiante".equalsIgnoreCase(usuario.getRol())) {
            tabbedPane.addTab("Catálogo y Mis Préstamos", new GestionPrestamosPanel(servicio, false));
        }

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        JLabel lblInfo = new JLabel("Sesión Activa: " + usuario.getNombre() + " [" + usuario.getRol().toUpperCase() + "]");
        lblInfo.setFont(new Font("Arial", Font.BOLD, 12));

        JButton btnCerrarSesion = new JButton("Cerrar Sesión");

        btnCerrarSesion.addActionListener(e -> {
            servicio.cerrarSesion();
            this.dispose();
            new LoginView().setVisible(true);
        });

        topPanel.add(lblInfo, BorderLayout.WEST);
        topPanel.add(btnCerrarSesion, BorderLayout.EAST);

        add(topPanel, BorderLayout.NORTH);
        add(tabbedPane, BorderLayout.CENTER);
    }
}