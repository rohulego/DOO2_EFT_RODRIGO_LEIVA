package cl.duoc.biblioteca.dao;

import cl.duoc.biblioteca.conexion.DatabaseConnection;
import cl.duoc.biblioteca.modelo.Libro;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LibroDAO {

    public boolean insertar(Libro l) {
        String sql = "INSERT INTO libros (titulo, autor, isbn, editorial, stock, id_categoria) VALUES (?, ?, ?, ?, ?, ?)";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, l.getTitulo());
            stmt.setString(2, l.getAutor());
            stmt.setString(3, l.getIsbn());
            stmt.setString(4, l.getEditorial());
            stmt.setInt(5, l.getStock());
            stmt.setInt(6, l.getIdCategoria());

            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al insertar libro: " + ex.getMessage());
            return false;
        }
    }

    public List<Libro> listarTodos() {
        List<Libro> lista = new ArrayList<>();
        String sql = "SELECT l.*, c.nombre AS categoria_nombre " +
                "FROM libros l " +
                "JOIN categorias c ON l.id_categoria = c.id " +
                "ORDER BY l.titulo ASC";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Libro libro = new Libro(
                        rs.getInt("id"),
                        rs.getString("titulo"),
                        rs.getString("autor"),
                        rs.getString("isbn"),
                        rs.getString("editorial"),
                        rs.getInt("stock"),
                        rs.getInt("id_categoria")
                );
                libro.setNombreCategoria(rs.getString("categoria_nombre"));
                lista.add(libro);
            }
        } catch (SQLException ex) {
            System.err.println("Error al listar libros: " + ex.getMessage());
        }
        return lista;
    }

    public List<Libro> buscarPorCriterio(String filtro) {
        List<Libro> lista = new ArrayList<>();
        String sql = "SELECT l.*, c.nombre AS categoria_nombre " +
                "FROM libros l " +
                "JOIN categorias c ON l.id_categoria = c.id " +
                "WHERE l.titulo LIKE ? OR l.autor LIKE ? OR c.nombre LIKE ? " +
                "ORDER BY l.titulo ASC";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            String parametro = "%" + filtro + "%";
            stmt.setString(1, parametro);
            stmt.setString(2, parametro);
            stmt.setString(3, parametro);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Libro libro = new Libro(
                            rs.getInt("id"),
                            rs.getString("titulo"),
                            rs.getString("autor"),
                            rs.getString("isbn"),
                            rs.getString("editorial"),
                            rs.getInt("stock"),
                            rs.getInt("id_categoria")
                    );
                    libro.setNombreCategoria(rs.getString("categoria_nombre"));
                    lista.add(libro);
                }
            }
        } catch (SQLException ex) {
            System.err.println("Error al buscar libros: " + ex.getMessage());
        }
        return lista;
    }

    public boolean actualizar(Libro l) {
        String sql = "UPDATE libros SET titulo = ?, autor = ?, isbn = ?, editorial = ?, stock = ?, id_categoria = ? WHERE id = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, l.getTitulo());
            stmt.setString(2, l.getAutor());
            stmt.setString(3, l.getIsbn());
            stmt.setString(4, l.getEditorial());
            stmt.setInt(5, l.getStock());
            stmt.setInt(6, l.getIdCategoria());
            stmt.setInt(7, l.getId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al actualizar libro: " + ex.getMessage());
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM libros WHERE id = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al eliminar libro: " + ex.getMessage());
            return false;
        }
    }

    public Libro obtenerPorId(int id) {
        String sql = "SELECT * FROM libros WHERE id = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Libro(
                            rs.getInt("id"),
                            rs.getString("titulo"),
                            rs.getString("autor"),
                            rs.getString("isbn"),
                            rs.getString("editorial"),
                            rs.getInt("stock"),
                            rs.getInt("id_categoria")
                    );
                }
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener libro por id: " + ex.getMessage());
        }
        return null;
    }

    // Sobrecarga que permite ejecutar dentro de una transacción activa
    public boolean actualizarStockTransaccional(Connection conn, int idLibro, int nuevoStock) throws SQLException {
        String sql = "UPDATE libros SET stock = ? WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, nuevoStock);
            stmt.setInt(2, idLibro);
            return stmt.executeUpdate() > 0;
        }
    }
}