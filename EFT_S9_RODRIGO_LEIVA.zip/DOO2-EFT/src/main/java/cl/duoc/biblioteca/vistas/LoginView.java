package cl.duoc.biblioteca.vistas;

import cl.duoc.biblioteca.modelo.Usuario;
import cl.duoc.biblioteca.service.BibliotecaService;

import javax.swing.*;
import java.awt.*;

public class LoginView extends JFrame {

    private JTextField txtRut;
    private JPasswordField txtContrasena;
    private JButton btnIngresar;
    private JButton btnSalir;
    private final BibliotecaService servicio;

    public LoginView() {
        this.servicio = new BibliotecaService();
        initUI();
    }

    private void initUI() {
        setTitle("Biblioteca Escolar - Iniciar Sesión");
        setSize(400, 260);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitulo = new JLabel("Acceso al Sistema", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        mainPanel.add(lblTitulo, gbc);

        gbc.gridwidth = 1;
        gbc.gridx = 0; gbc.gridy = 1;
        mainPanel.add(new JLabel("RUT:"), gbc);

        txtRut = new JTextField(15);
        gbc.gridx = 1; gbc.gridy = 1;
        mainPanel.add(txtRut, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        mainPanel.add(new JLabel("Contraseña:"), gbc);

        txtContrasena = new JPasswordField(15);
        gbc.gridx = 1; gbc.gridy = 2;
        mainPanel.add(txtContrasena, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnIngresar = new JButton("Ingresar");
        btnSalir = new JButton("Salir");
        buttonPanel.add(btnIngresar);
        buttonPanel.add(btnSalir);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        mainPanel.add(buttonPanel, gbc);

        add(mainPanel);

        btnIngresar.addActionListener(e -> procesarLogin());
        btnSalir.addActionListener(e -> System.exit(0));

        getRootPane().setDefaultButton(btnIngresar);
    }

    private void procesarLogin() {
        String rut = txtRut.getText().trim();
        String clave = new String(txtContrasena.getPassword()).trim();

        try {
            Usuario usuario = servicio.iniciarSesion(rut, clave);
            if (usuario != null) {
                JOptionPane.showMessageDialog(this, "Bienvenido(a), " + usuario.getNombre(), "Acceso Concedido", JOptionPane.INFORMATION_MESSAGE);
                this.dispose();
                new MainView(servicio).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "RUT o contraseña incorrectos.", "Error de Autenticación", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Atención", JOptionPane.WARNING_MESSAGE);
        }
    }
}