package cl.duoc.biblioteca.vistas;

import cl.duoc.biblioteca.modelo.Estudiante;
import cl.duoc.biblioteca.modelo.Libro;
import cl.duoc.biblioteca.modelo.Prestamo;
import cl.duoc.biblioteca.modelo.SesionUsuario;
import cl.duoc.biblioteca.service.BibliotecaService;
import cl.duoc.biblioteca.service.HiloRegistroPrestamos;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class GestionPrestamosPanel extends JPanel {

    private final BibliotecaService servicio;
    private final boolean esBibliotecario;

    private JTable tablaLibros;
    private DefaultTableModel modelLibros;

    private JTable tablaPrestamos;
    private DefaultTableModel modelPrestamos;

    private JComboBox<Estudiante> cbEstudiantes;
    private JSpinner spDias;
    private JButton btnSolicitar;
    private JButton btnDevolver;
    private JButton btnRefrescar;

    public GestionPrestamosPanel(BibliotecaService servicio, boolean esBibliotecario) {
        this.servicio = servicio;
        this.esBibliotecario = esBibliotecario;
        setLayout(new GridLayout(2, 1, 10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        initUI();
        cargarDatos(); // Carga automática de libros, estudiantes y préstamos desde MySQL
    }

    private void initUI() {
        // Panel Superior: Libros Disponibles
        JPanel panelLibros = new JPanel(new BorderLayout(5, 5));
        panelLibros.setBorder(BorderFactory.createTitledBorder("Libros Disponibles para Préstamo"));

        modelLibros = new DefaultTableModel(new String[]{"ID", "Título", "Autor", "Stock", "Categoría"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tablaLibros = new JTable(modelLibros);
        panelLibros.add(new JScrollPane(tablaLibros), BorderLayout.CENTER);

        JPanel panelAccionPrestamo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        spDias = new JSpinner(new SpinnerNumberModel(7, 1, 30, 1));
        btnSolicitar = new JButton("Solicitar Préstamo (Multihilo)");
        btnRefrescar = new JButton("Refrescar Listas");

        if (esBibliotecario) {
            cbEstudiantes = new JComboBox<>();
            panelAccionPrestamo.add(new JLabel("Seleccionar Estudiante:"));
            panelAccionPrestamo.add(cbEstudiantes);
        }

        panelAccionPrestamo.add(new JLabel("Días:"));
        panelAccionPrestamo.add(spDias);
        panelAccionPrestamo.add(btnSolicitar);
        panelAccionPrestamo.add(btnRefrescar);
        panelLibros.add(panelAccionPrestamo, BorderLayout.SOUTH);

        // Panel Inferior: Historial de Préstamos
        JPanel panelPrestamos = new JPanel(new BorderLayout(5, 5));
        panelPrestamos.setBorder(BorderFactory.createTitledBorder(esBibliotecario ? "Todos los Préstamos Registrados" : "Mis Préstamos"));

        modelPrestamos = new DefaultTableModel(new String[]{"ID", "Estudiante", "Libro", "Fecha Préstamo", "Fecha Devolución", "Estado"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tablaPrestamos = new JTable(modelPrestamos);
        panelPrestamos.add(new JScrollPane(tablaPrestamos), BorderLayout.CENTER);

        btnDevolver = new JButton("Registrar Devolución");
        JPanel panelAccionDevolucion = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelAccionDevolucion.add(btnDevolver);
        panelPrestamos.add(panelAccionDevolucion, BorderLayout.SOUTH);

        add(panelLibros);
        add(panelPrestamos);

        // Eventos
        btnRefrescar.addActionListener(e -> cargarDatos());
        btnSolicitar.addActionListener(e -> solicitarPrestamoHilo());
        btnDevolver.addActionListener(e -> devolverPrestamo());
    }

    public void cargarDatos() {
        cargarLibros();
        if (esBibliotecario) {
            cargarEstudiantes();
        }
        cargarPrestamos();
    }

    private void cargarLibros() {
        modelLibros.setRowCount(0);
        List<Libro> libros = servicio.listarLibros();
        if (libros != null) {
            for (Libro l : libros) {
                modelLibros.addRow(new Object[]{l.getId(), l.getTitulo(), l.getAutor(), l.getStock(), l.getNombreCategoria()});
            }
        }
    }

    private void cargarEstudiantes() {
        cbEstudiantes.removeAllItems();
        List<Estudiante> estudiantes = servicio.listarEstudiantes();
        if (estudiantes != null) {
            for (Estudiante e : estudiantes) {
                cbEstudiantes.addItem(e);
            }
        }
    }

    private void cargarPrestamos() {
        modelPrestamos.setRowCount(0);
        List<Prestamo> lista;

        if (esBibliotecario) {
            lista = servicio.listarTodosLosPrestamos();
        } else {
            Estudiante estLogueado = servicio.obtenerEstudiantePorRut(SesionUsuario.getUsuarioLogueado().getRut());
            if (estLogueado != null) {
                lista = servicio.listarPrestamosPorEstudiante(estLogueado.getId());
            } else {
                lista = List.of();
            }
        }

        if (lista != null) {
            for (Prestamo p : lista) {
                modelPrestamos.addRow(new Object[]{
                        p.getId(),
                        p.getNombreEstudiante(),
                        p.getTituloLibro(),
                        p.getFechaPrestamo(),
                        p.getFechaDevolucion() != null ? p.getFechaDevolucion() : "En uso",
                        p.getEstado() // <--- Llama dinámicamente al Enum/Método (DEVUELTO, PENDIENTE o ATRASADO)
                });
            }
        }
    }

    private void solicitarPrestamoHilo() {
        int rowLibro = tablaLibros.getSelectedRow();
        if (rowLibro < 0) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar un libro de la tabla superior.", "Atención", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int idLibro = (int) modelLibros.getValueAt(rowLibro, 0);
        int idEstudiante;

        if (esBibliotecario) {
            Estudiante est = (Estudiante) cbEstudiantes.getSelectedItem();
            if (est == null) {
                JOptionPane.showMessageDialog(this, "Debe seleccionar un estudiante.", "Atención", JOptionPane.WARNING_MESSAGE);
                return;
            }
            idEstudiante = est.getId();
        } else {
            Estudiante estLogueado = servicio.obtenerEstudiantePorRut(SesionUsuario.getUsuarioLogueado().getRut());
            if (estLogueado == null) {
                JOptionPane.showMessageDialog(this, "El usuario actual no está vinculado a un registro de estudiante.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            idEstudiante = estLogueado.getId();
        }

        int dias = (int) spDias.getValue();

        HiloRegistroPrestamos.ejecutarEnSegundoPlano(servicio, idEstudiante, idLibro, dias, () -> cargarDatos());
    }

    private void devolverPrestamo() {
        int rowPrestamo = tablaPrestamos.getSelectedRow();
        if (rowPrestamo < 0) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar un préstamo de la tabla inferior.", "Atención", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int idPrestamo = (int) modelPrestamos.getValueAt(rowPrestamo, 0);

        try {
            if (servicio.registrarDevolucion(idPrestamo)) {
                JOptionPane.showMessageDialog(this, "Devolución registrada exitosamente.");
                cargarDatos();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Atención", JOptionPane.WARNING_MESSAGE);
        }
    }
}