package cl.duoc.biblioteca.service;

import cl.duoc.biblioteca.dao.*;
import cl.duoc.biblioteca.modelo.*;

import java.time.LocalDate;
import java.util.List;

public class BibliotecaService {

    private final UsuarioDAO usuarioDAO;
    private final EstudianteDAO estudianteDAO;
    private final LibroDAO libroDAO;
    private final CategoriaDAO categoriaDAO;
    private final PrestamoDAO prestamoDAO;

    public BibliotecaService() {
        this.usuarioDAO = new UsuarioDAO();
        this.estudianteDAO = new EstudianteDAO();
        this.libroDAO = new LibroDAO();
        this.categoriaDAO = new CategoriaDAO();
        this.prestamoDAO = new PrestamoDAO();
    }



    public Usuario iniciarSesion(String rut, String contrasena) {
        if (rut == null || rut.trim().isEmpty() || contrasena == null || contrasena.trim().isEmpty()) {
            throw new IllegalArgumentException("Debe ingresar el RUT y la contraseña.");
        }

        Usuario usuario = usuarioDAO.autenticar(rut.trim(), contrasena.trim());
        if (usuario != null) {
            SesionUsuario.setUsuarioLogueado(usuario);
        }
        return usuario;
    }

    public void cerrarSesion() {
        SesionUsuario.cerrarSesion();
    }



    public Estudiante obtenerEstudiantePorRut(String rut) {
        if (rut == null || rut.trim().isEmpty()) {
            return null;
        }
        return estudianteDAO.obtenerPorRut(rut.trim());
    }

    public boolean guardarEstudiante(Estudiante estudiante) {
        if (estudiante.getRut() == null || estudiante.getRut().trim().isEmpty()) {
            throw new IllegalArgumentException("El RUT del estudiante es obligatorio.");
        }
        if (estudiante.getNombre() == null || estudiante.getNombre().trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del estudiante es obligatorio.");
        }

        if (estudiante.getId() == 0) {
            return estudianteDAO.insertar(estudiante);
        } else {
            return estudianteDAO.actualizar(estudiante);
        }
    }

    public boolean eliminarEstudiante(int id) {
        // Si tiene préstamos pendientes, no permitimos eliminar
        if (estudianteDAO.tienePrestamosPendientes(id)) {
            return false;
        }
        return estudianteDAO.eliminar(id);
    }

    public boolean estudianteTienePendientes(int id) {
        return estudianteDAO.tienePrestamosPendientes(id);
    }

    public List<Estudiante> listarEstudiantes() {
        return estudianteDAO.listarTodos();
    }



    public boolean guardarLibro(Libro libro) {
        if (libro.getTitulo() == null || libro.getTitulo().trim().isEmpty()) {
            throw new IllegalArgumentException("El título del libro es obligatorio.");
        }
        if (libro.getStock() < 0) {
            throw new IllegalArgumentException("El stock no puede ser negativo.");
        }

        if (libro.getId() == 0) {
            return libroDAO.insertar(libro);
        } else {
            return libroDAO.actualizar(libro);
        }
    }

    public boolean eliminarLibro(int idLibro) {
        return libroDAO.eliminar(idLibro);
    }

    public List<Libro> listarLibros() {
        return libroDAO.listarTodos();
    }

    public List<Libro> buscarLibros(String filtro) {
        if (filtro == null || filtro.trim().isEmpty()) {
            return listarLibros();
        }
        return libroDAO.buscarPorCriterio(filtro.trim());
    }

    public List<Categoria> listarCategorias() {
        return categoriaDAO.obtenerTodas();
    }



    public synchronized boolean solicitarPrestamo(int idEstudiante, int idLibro, int diasPrestamo) {
        if (diasPrestamo <= 0 || diasPrestamo > 30) {
            throw new IllegalArgumentException("El plazo del préstamo debe ser entre 1 y 30 días.");
        }

        Libro libro = libroDAO.obtenerPorId(idLibro);
        if (libro == null) {
            throw new IllegalArgumentException("El libro seleccionado no existe.");
        }
        if (libro.getStock() <= 0) {
            throw new IllegalStateException("El libro '" + libro.getTitulo() + "' no tiene stock disponible.");
        }

        LocalDate fechaActual = LocalDate.now();
        LocalDate fechaDevolucionEstimada = fechaActual.plusDays(diasPrestamo);

        Prestamo nuevoPrestamo = new Prestamo(
                idEstudiante,
                idLibro,
                fechaActual,
                fechaDevolucionEstimada,
                false
        );

        return prestamoDAO.procesarPrestamoTransaccional(nuevoPrestamo, libro.getStock());
    }

    public synchronized boolean registrarDevolucion(int idPrestamo) {
        Prestamo prestamoTarget = prestamoDAO.obtenerPorId(idPrestamo);

        if (prestamoTarget == null) {
            throw new IllegalArgumentException("El préstamo indicado no existe.");
        }
        if (prestamoTarget.isDevuelto()) {
            throw new IllegalStateException("Este préstamo ya fue marcado como devuelto previamente.");
        }

        Libro libro = libroDAO.obtenerPorId(prestamoTarget.getIdLibro());
        if (libro == null) {
            throw new IllegalArgumentException("El libro asociado al préstamo no existe.");
        }

        return prestamoDAO.procesarDevolucionTransaccional(
                idPrestamo,
                prestamoTarget.getIdLibro(),
                libro.getStock(),
                LocalDate.now()
        );
    }

    public List<Prestamo> listarTodosLosPrestamos() {
        return prestamoDAO.listarTodos();
    }

    public List<Prestamo> listarPrestamosPorEstudiante(int idEstudiante) {
        return prestamoDAO.obtenerPorEstudiante(idEstudiante);
    }

    public List<Object[]> obtenerReporteLibrosMasPrestados() {
        return prestamoDAO.obtenerLibrosMasPrestados();
    }

    public List<Object[]> obtenerHistorialEstudiante(int idEstudiante) {
        return prestamoDAO.obtenerHistorialPorEstudiante(idEstudiante);
    }
}