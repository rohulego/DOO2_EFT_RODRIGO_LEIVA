package cl.duoc.biblioteca.dao;

import cl.duoc.biblioteca.conexion.DatabaseConnection;
import cl.duoc.biblioteca.modelo.Prestamo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PrestamoDAO {

    private static final Set<Integer> devueltosConAtraso = new HashSet<>();

    private final LibroDAO libroDAO = new LibroDAO();


    public synchronized boolean procesarPrestamoTransaccional(Prestamo p, int stockActual) {
        Connection conn = DatabaseConnection.getInstance().getConnection();
        boolean exito = false;

        try {
            conn.setAutoCommit(false);


            String sqlPrestamo = "INSERT INTO prestamos (id_estudiante, id_libro, fecha_prestamo, fecha_devolucion, devuelto) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sqlPrestamo)) {
                stmt.setInt(1, p.getIdEstudiante());
                stmt.setInt(2, p.getIdLibro());
                stmt.setDate(3, Date.valueOf(p.getFechaPrestamo()));

                if (p.getFechaDevolucion() != null) {
                    stmt.setDate(4, Date.valueOf(p.getFechaDevolucion()));
                } else {
                    stmt.setNull(4, Types.DATE);
                }

                stmt.setBoolean(5, p.isDevuelto());
                stmt.executeUpdate();
            }


            boolean stockActualizado = libroDAO.actualizarStockTransaccional(conn, p.getIdLibro(), stockActual - 1);

            if (stockActualizado) {
                conn.commit();
                exito = true;
            } else {
                conn.rollback();
            }
        } catch (SQLException ex) {
            try {
                conn.rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Error en rollback: " + rollbackEx.getMessage());
            }
            System.err.println("Error en transacción de préstamo: " + ex.getMessage());
        } finally {
            try {
                conn.setAutoCommit(true);
            } catch (SQLException ex) {
                System.err.println("Error restaurando autoCommit: " + ex.getMessage());
            }
        }
        return exito;
    }


    public synchronized boolean procesarDevolucionTransaccional(int idPrestamo, int idLibro, int stockActual, LocalDate fechaActual) {
        Prestamo p = obtenerPorId(idPrestamo);

        // Si el préstamo tenía fecha pactada y la fecha actual de entrega es estrictamente posterior a esa fecha
        if (p != null && p.getFechaDevolucion() != null && fechaActual.isAfter(p.getFechaDevolucion())) {
            devueltosConAtraso.add(idPrestamo);
        }

        Connection conn = DatabaseConnection.getInstance().getConnection();
        boolean exito = false;

        try {
            conn.setAutoCommit(false);

            // Marcamos devuelto = true conservando la fecha límite original
            String sqlDevolucion = "UPDATE prestamos SET devuelto = true WHERE id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlDevolucion)) {
                stmt.setInt(1, idPrestamo);
                stmt.executeUpdate();
            }

            boolean stockActualizado = libroDAO.actualizarStockTransaccional(conn, idLibro, stockActual + 1);

            if (stockActualizado) {
                conn.commit();
                exito = true;
            } else {
                conn.rollback();
            }
        } catch (SQLException ex) {
            try {
                conn.rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Error en rollback: " + rollbackEx.getMessage());
            }
            System.err.println("Error en transacción de devolución: " + ex.getMessage());
        } finally {
            try {
                conn.setAutoCommit(true);
            } catch (SQLException ex) {
                System.err.println("Error restaurando autoCommit: " + ex.getMessage());
            }
        }
        return exito;
    }


    public static boolean esDevueltoConAtraso(int idPrestamo) {
        return devueltosConAtraso.contains(idPrestamo);
    }


    public List<Prestamo> listarTodos() {
        List<Prestamo> lista = new ArrayList<>();
        String sql = "SELECT p.*, e.nombre AS estudiante_nombre, l.titulo AS libro_titulo " +
                "FROM prestamos p " +
                "JOIN estudiantes e ON p.id_estudiante = e.id " +
                "JOIN libros l ON p.id_libro = l.id " +
                "ORDER BY p.fecha_prestamo DESC";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {



            while (rs.next()) {
                Date fechaDevSql = rs.getDate("fecha_devolucion");
                LocalDate fechaDev = (fechaDevSql != null) ? fechaDevSql.toLocalDate() : null;

                Prestamo p = new Prestamo(
                        rs.getInt("id"),
                        rs.getInt("id_estudiante"),
                        rs.getInt("id_libro"),
                        rs.getDate("fecha_prestamo").toLocalDate(),
                        fechaDev,
                        rs.getBoolean("devuelto")
                );
                p.setNombreEstudiante(rs.getString("estudiante_nombre"));
                p.setTituloLibro(rs.getString("libro_titulo"));
                lista.add(p);
            }
        } catch (SQLException ex) {
            System.err.println("Error al listar préstamos: " + ex.getMessage());
        }
        return lista;
    }

    public List<Prestamo> obtenerPorEstudiante(int idEstudiante) {
        List<Prestamo> lista = new ArrayList<>();
        String sql = "SELECT p.*, e.nombre AS estudiante_nombre, l.titulo AS libro_titulo " +
                "FROM prestamos p " +
                "JOIN estudiantes e ON p.id_estudiante = e.id " +
                "JOIN libros l ON p.id_libro = l.id " +
                "WHERE p.id_estudiante = ? " +
                "ORDER BY p.fecha_prestamo DESC";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idEstudiante);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Date fechaDevSql = rs.getDate("fecha_devolucion");
                    LocalDate fechaDev = (fechaDevSql != null) ? fechaDevSql.toLocalDate() : null;

                    Prestamo p = new Prestamo(
                            rs.getInt("id"),
                            rs.getInt("id_estudiante"),
                            rs.getInt("id_libro"),
                            rs.getDate("fecha_prestamo").toLocalDate(),
                            fechaDev,
                            rs.getBoolean("devuelto")
                    );
                    p.setNombreEstudiante(rs.getString("estudiante_nombre"));
                    p.setTituloLibro(rs.getString("libro_titulo"));
                    lista.add(p);
                }
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener préstamos por estudiante: " + ex.getMessage());
        }
        return lista;
    }

    public Prestamo obtenerPorId(int id) {
        String sql = "SELECT p.*, e.nombre AS estudiante_nombre, l.titulo AS libro_titulo " +
                "FROM prestamos p " +
                "JOIN estudiantes e ON p.id_estudiante = e.id " +
                "JOIN libros l ON p.id_libro = l.id " +
                "WHERE p.id = ?";
        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Date fechaDevSql = rs.getDate("fecha_devolucion");
                    LocalDate fechaDev = (fechaDevSql != null) ? fechaDevSql.toLocalDate() : null;

                    Prestamo p = new Prestamo(
                            rs.getInt("id"),
                            rs.getInt("id_estudiante"),
                            rs.getInt("id_libro"),
                            rs.getDate("fecha_prestamo").toLocalDate(),
                            fechaDev,
                            rs.getBoolean("devuelto")
                    );
                    p.setNombreEstudiante(rs.getString("estudiante_nombre"));
                    p.setTituloLibro(rs.getString("libro_titulo"));
                    return p;
                }
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener préstamo por ID: " + ex.getMessage());
        }
        return null;
    }

    public List<Object[]> obtenerLibrosMasPrestados() {
        List<Object[]> reporte = new ArrayList<>();
        String sql = "SELECT l.titulo, l.autor, COUNT(p.id) AS total_prestamos " +
                "FROM prestamos p " +
                "JOIN libros l ON p.id_libro = l.id " +
                "GROUP BY l.id, l.titulo, l.autor " +
                "ORDER BY total_prestamos DESC";

        Connection conn = DatabaseConnection.getInstance().getConnection();

        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                reporte.add(new Object[]{
                        rs.getString("titulo"),
                        rs.getString("autor"),
                        rs.getInt("total_prestamos")
                });
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener libros más prestados: " + ex.getMessage());
        }
        return reporte;
    }


    public List<Object[]> obtenerHistorialPorEstudiante(int idEstudiante) {
        List<Object[]> historial = new ArrayList<>();
        List<Prestamo> prestamos = obtenerPorEstudiante(idEstudiante);

        for (Prestamo p : prestamos) {
            historial.add(new Object[]{
                    p.getTituloLibro(),
                    p.getFechaPrestamo(),
                    p.getFechaDevolucion() != null ? p.getFechaDevolucion() : "En uso",
                    p.getEstado() // Retorna PENDIENTE, ATRASADO, DEVUELTO o DEVUELTO_CON_ATRASO
            });
        }
        return historial;
    }
}