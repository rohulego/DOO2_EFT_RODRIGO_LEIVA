package cl.duoc.biblioteca.vistas;

import cl.duoc.biblioteca.modelo.Categoria;
import cl.duoc.biblioteca.modelo.Libro;
import cl.duoc.biblioteca.service.BibliotecaService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class GestionLibrosPanel extends JPanel {

    private final BibliotecaService servicio;
    private JTable tablaLibros;
    private DefaultTableModel modelTabla;
    private JTextField txtTitulo, txtAutor, txtIsbn, txtEditorial, txtStock, txtBuscar;
    private JComboBox<Categoria> cbCategorias;
    private JButton btnGuardar, btnLimpiar, btnEliminar, btnBuscar, btnListar;
    private int idSeleccionado = 0;

    public GestionLibrosPanel(BibliotecaService servicio) {
        this.servicio = servicio;
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        initUI();
        cargarCategorias();
        cargarTabla(); // Carga automática de MySQL Workbench
    }

    private void initUI() {
        // Panel Superior: Búsqueda y Filtro
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        txtBuscar = new JTextField(15);
        btnBuscar = new JButton("Buscar Filtro");
        btnListar = new JButton("Listar Todo");

        searchPanel.add(new JLabel("Filtro:"));
        searchPanel.add(txtBuscar);
        searchPanel.add(btnBuscar);
        searchPanel.add(btnListar);

        // Panel Formularios
        JPanel formPanel = new JPanel(new GridLayout(6, 2, 8, 8));
        formPanel.setBorder(BorderFactory.createTitledBorder("Datos del Libro"));

        txtTitulo = new JTextField();
        txtAutor = new JTextField();
        txtIsbn = new JTextField();
        txtEditorial = new JTextField();
        txtStock = new JTextField();
        cbCategorias = new JComboBox<>();

        formPanel.add(new JLabel("Título:"));
        formPanel.add(txtTitulo);
        formPanel.add(new JLabel("Autor:"));
        formPanel.add(txtAutor);
        formPanel.add(new JLabel("ISBN:"));
        formPanel.add(txtIsbn);
        formPanel.add(new JLabel("Editorial:"));
        formPanel.add(txtEditorial);
        formPanel.add(new JLabel("Stock:"));
        formPanel.add(txtStock);
        formPanel.add(new JLabel("Categoría:"));
        formPanel.add(cbCategorias);

        // Botones de Acción
        btnGuardar = new JButton("Guardar / Actualizar");
        btnLimpiar = new JButton("Limpiar / Nuevo");
        btnEliminar = new JButton("Eliminar Seleccionado");

        JPanel formButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        formButtons.add(btnGuardar);
        formButtons.add(btnLimpiar);
        formButtons.add(btnEliminar);

        JPanel topContainer = new JPanel(new BorderLayout());
        topContainer.add(searchPanel, BorderLayout.NORTH);
        topContainer.add(formPanel, BorderLayout.CENTER);
        topContainer.add(formButtons, BorderLayout.SOUTH);

        // Tabla de Datos
        modelTabla = new DefaultTableModel(new String[]{"ID", "Título", "Autor", "ISBN", "Editorial", "Stock", "Categoría"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tablaLibros = new JTable(modelTabla);
        JScrollPane scrollTabla = new JScrollPane(tablaLibros);

        add(topContainer, BorderLayout.NORTH);
        add(scrollTabla, BorderLayout.CENTER);

        // Eventos de los Botones
        btnBuscar.addActionListener(e -> buscarLibros());
        btnListar.addActionListener(e -> cargarTabla());
        btnGuardar.addActionListener(e -> guardarLibro());
        btnLimpiar.addActionListener(e -> limpiarFormulario());
        btnEliminar.addActionListener(e -> eliminarLibro());

        // Evento al Seleccionar una Fila de la Tabla
        tablaLibros.getSelectionModel().addListSelectionListener(e -> {
            int row = tablaLibros.getSelectedRow();
            if (row >= 0) {
                idSeleccionado = (int) modelTabla.getValueAt(row, 0);
                txtTitulo.setText((String) modelTabla.getValueAt(row, 1));
                txtAutor.setText((String) modelTabla.getValueAt(row, 2));
                txtIsbn.setText((String) modelTabla.getValueAt(row, 3));
                txtEditorial.setText((String) modelTabla.getValueAt(row, 4));
                txtStock.setText(String.valueOf(modelTabla.getValueAt(row, 5)));

                String nombreCat = (String) modelTabla.getValueAt(row, 6);
                for (int i = 0; i < cbCategorias.getItemCount(); i++) {
                    if (cbCategorias.getItemAt(i).getNombre().equalsIgnoreCase(nombreCat)) {
                        cbCategorias.setSelectedIndex(i);
                        break;
                    }
                }
            }
        });
    }

    private void cargarCategorias() {
        cbCategorias.removeAllItems();
        List<Categoria> categorias = servicio.listarCategorias();
        if (categorias != null) {
            for (Categoria c : categorias) {
                cbCategorias.addItem(c);
            }
        }
    }

    public void cargarTabla() {
        modelTabla.setRowCount(0);
        List<Libro> lista = servicio.listarLibros();
        if (lista != null) {
            for (Libro l : lista) {
                modelTabla.addRow(new Object[]{l.getId(), l.getTitulo(), l.getAutor(), l.getIsbn(), l.getEditorial(), l.getStock(), l.getNombreCategoria()});
            }
        }
    }

    private void buscarLibros() {
        modelTabla.setRowCount(0);
        List<Libro> lista = servicio.buscarLibros(txtBuscar.getText());
        if (lista != null) {
            for (Libro l : lista) {
                modelTabla.addRow(new Object[]{l.getId(), l.getTitulo(), l.getAutor(), l.getIsbn(), l.getEditorial(), l.getStock(), l.getNombreCategoria()});
            }
        }
    }

    private void guardarLibro() {
        try {
            Categoria cat = (Categoria) cbCategorias.getSelectedItem();
            int stock = Integer.parseInt(txtStock.getText().trim());

            Libro l = new Libro(idSeleccionado, txtTitulo.getText().trim(), txtAutor.getText().trim(), txtIsbn.getText().trim(), txtEditorial.getText().trim(), stock, cat != null ? cat.getId() : 1);
            if (servicio.guardarLibro(l)) {
                JOptionPane.showMessageDialog(this, "Libro procesado con éxito.");
                limpiarFormulario();
                cargarTabla();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "El stock debe ser un número entero válido.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarLibro() {
        if (idSeleccionado == 0) {
            JOptionPane.showMessageDialog(this, "Seleccione un libro de la tabla.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "¿Eliminar este libro?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (servicio.eliminarLibro(idSeleccionado)) {
                JOptionPane.showMessageDialog(this, "Libro eliminado.");
                limpiarFormulario();
                cargarTabla();
            }
        }
    }

    private void limpiarFormulario() {
        idSeleccionado = 0;
        txtTitulo.setText("");
        txtAutor.setText("");
        txtIsbn.setText("");
        txtEditorial.setText("");
        txtStock.setText("");
        tablaLibros.clearSelection();
    }
}