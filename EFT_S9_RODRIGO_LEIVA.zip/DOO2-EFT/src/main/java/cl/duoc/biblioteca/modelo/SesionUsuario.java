package cl.duoc.biblioteca.modelo;

public class SesionUsuario {
    private static Usuario usuarioLogueado;

    public static void setUsuarioLogueado(Usuario usuario) {
        usuarioLogueado = usuario;
    }

    public static Usuario getUsuarioLogueado() {
        return usuarioLogueado;
    }

    public static boolean esBibliotecario() {
        return usuarioLogueado != null && "BIBLIOTECARIO".equalsIgnoreCase(usuarioLogueado.getRol());
    }

    public static boolean esEstudiante() {
        return usuarioLogueado != null && "ESTUDIANTE".equalsIgnoreCase(usuarioLogueado.getRol());
    }

    public static void cerrarSesion() {
        usuarioLogueado = null;
    }
}