package cl.duoc.biblioteca.vistas;

import cl.duoc.biblioteca.modelo.Estudiante;
import cl.duoc.biblioteca.service.BibliotecaService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ReportesPanel extends JPanel {

    private final BibliotecaService servicio;
    private DefaultTableModel modelMasPrestados;
    private DefaultTableModel modelHistorial;
    private JComboBox<Estudiante> cbEstudiantes;

    public ReportesPanel(BibliotecaService servicio) {
        this.servicio = servicio;
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        initUI();
    }

    private void initUI() {
        JTabbedPane subTabs = new JTabbedPane();

        // Sub-pestaña 1: Libros Más Prestados
        JPanel panelMasPrestados = new JPanel(new BorderLayout(5, 5));
        modelMasPrestados = new DefaultTableModel(new String[]{"Título", "Autor", "Cant. Préstamos"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tablaMasPrestados = new JTable(modelMasPrestados);
        JButton btnRefrescarMasPrestados = new JButton("Actualizar Ranking");
        btnRefrescarMasPrestados.addActionListener(e -> cargarLibrosMasPrestados());

        JPanel topP1 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        topP1.add(btnRefrescarMasPrestados);

        panelMasPrestados.add(topP1, BorderLayout.NORTH);
        panelMasPrestados.add(new JScrollPane(tablaMasPrestados), BorderLayout.CENTER);

        // Sub-pestaña 2: Historial por Estudiante
        JPanel panelHistorial = new JPanel(new BorderLayout(5, 5));
        JPanel topP2 = new JPanel(new FlowLayout(FlowLayout.LEFT));

        cbEstudiantes = new JComboBox<>();
        JButton btnBuscarHistorial = new JButton("Consultar Historial");

        topP2.add(new JLabel("Seleccionar Estudiante:"));
        topP2.add(cbEstudiantes);
        topP2.add(btnBuscarHistorial);

        modelHistorial = new DefaultTableModel(new String[]{"Libro", "F. Préstamo", "F. Devolución", "Estado"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tablaHistorial = new JTable(modelHistorial);

        panelHistorial.add(topP2, BorderLayout.NORTH);
        panelHistorial.add(new JScrollPane(tablaHistorial), BorderLayout.CENTER);

        btnBuscarHistorial.addActionListener(e -> cargarHistorialEstudiante());

        subTabs.addTab("Libros Más Prestados", panelMasPrestados);
        subTabs.addTab("Historial por Estudiante", panelHistorial);

        add(subTabs, BorderLayout.CENTER);

        // Carga inicial
        cargarEstudiantesCombo();
        cargarLibrosMasPrestados();
    }

    public void cargarLibrosMasPrestados() {
        modelMasPrestados.setRowCount(0);
        List<Object[]> datos = servicio.obtenerReporteLibrosMasPrestados();
        for (Object[] fila : datos) {
            modelMasPrestados.addRow(fila);
        }
    }

    public void cargarEstudiantesCombo() {
        cbEstudiantes.removeAllItems();
        List<Estudiante> lista = servicio.listarEstudiantes();
        if (lista != null) {
            for (Estudiante e : lista) {
                cbEstudiantes.addItem(e);
            }
        }
    }

    private void cargarHistorialEstudiante() {
        modelHistorial.setRowCount(0);
        Estudiante seleccionado = (Estudiante) cbEstudiantes.getSelectedItem();
        if (seleccionado != null) {
            List<Object[]> datos = servicio.obtenerHistorialEstudiante(seleccionado.getId());
            for (Object[] fila : datos) {
                modelHistorial.addRow(fila);
            }
        }
    }
}