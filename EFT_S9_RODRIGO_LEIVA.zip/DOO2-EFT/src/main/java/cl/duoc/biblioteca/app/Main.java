package cl.duoc.biblioteca.app;

import cl.duoc.biblioteca.vistas.LoginView;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Main {

    public static void main(String[] args) {
        // Aplicar la apariencia nativa del sistema operativo a Java Swing
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // Si falla, Swing utiliza la apariencia por defecto (Metal)
        }

        // Iniciar la interfaz en el hilo de eventos de Swing (EDT)
        SwingUtilities.invokeLater(() -> {
            LoginView login = new LoginView();
            login.setVisible(true);
        });
    }
}